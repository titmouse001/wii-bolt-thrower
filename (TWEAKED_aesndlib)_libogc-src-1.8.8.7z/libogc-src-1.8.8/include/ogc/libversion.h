#ifndef __LIBVERSION_H__
#define __LIBVERSION_H__

#define _V_MAJOR_	1
#define _V_MINOR_	8
#define _V_PATCH_	8

#define _V_DATE_			__DATE__
#define _V_TIME_			__TIME__

#define _V_STRING "libOGC Release 1.8.8"

#endif // __LIBVERSION_H__
